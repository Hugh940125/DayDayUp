package com.zjy.daydayup.DesignPatterns.Observer;

/**
 * Created by Hugh on 2018/6/19.
 *
 */

public interface IObserver {
    void OnUpdate(String str);
}
