package com.zjy.daydayup.Event;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;

/**
 * Created by Hugh on 2018/6/27.
 */

public class CustomTextView extends android.support.v7.widget.AppCompatTextView {
    public CustomTextView(Context context) {
        super(context);
    }

    public CustomTextView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.e("最内层","onTouchEvent -- ");
        return super.onTouchEvent(event);//super.onTouchEvent(event)
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        Log.e("最内层","dispatchTouchEvent -- ");
        return super.dispatchTouchEvent(event);
    }
}
