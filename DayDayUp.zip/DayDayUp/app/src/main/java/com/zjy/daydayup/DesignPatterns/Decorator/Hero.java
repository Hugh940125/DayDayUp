package com.zjy.daydayup.DesignPatterns.Decorator;

/**
 * Created by Hugh on 2018/6/22.
 */

public interface Hero {
    void learnSkill();
}
