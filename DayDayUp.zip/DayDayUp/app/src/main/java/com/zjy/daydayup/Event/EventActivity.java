package com.zjy.daydayup.Event;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.zjy.daydayup.R;

import butterknife.Bind;
import butterknife.ButterKnife;

public class EventActivity extends AppCompatActivity {

    @Bind(R.id.child)
    CustomTextView child;
    @Bind(R.id.sub_root)
    CustomLinearLayout subRoot;
    @Bind(R.id.root)
    CustomRelativeLayout root;
    private EventActivity mContext;
    private int heightPixels;
    private int widthPixels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);
        ButterKnife.bind(this);

        WindowManager windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (windowManager != null) {
            Display defaultDisplay = windowManager.getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            heightPixels = displayMetrics.heightPixels;
            widthPixels = displayMetrics.widthPixels;
        }

        child.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(EventActivity.this, "点击最里层", Toast.LENGTH_SHORT).show();
            }
        });

        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(EventActivity.this, "点击最外层", Toast.LENGTH_SHORT).show();
            }
        });

        subRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(EventActivity.this, "点击中间层", Toast.LENGTH_SHORT).show();
            }
        });

        /*child.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Toast.makeText(EventActivity.this, "点击最里层", Toast.LENGTH_SHORT).show();
                return false;
            }
        });*/

        subRoot.setOnTouchListener(new View.OnTouchListener() {

            private boolean isContain = false;

            private Rect rect = new Rect(widthPixels/2-550,heightPixels/2-550,widthPixels/2+550,heightPixels/2+550);

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        int x1 = (int)event.getX();
                        int y1 = (int)event.getY();
                        Log.e("down",x1+"--"+y1);
                        if (rect != null){
                            int bottom = rect.bottom;
                            int left = rect.left;
                            int right = rect.right;
                            int top = rect.top;
                            Log.e("down",bottom+"--"+left+"--"+right+"--"+top);
                            if (rect.contains(x1,y1)){
                                isContain = true;
                            }else {
                                isContain = false;
                            }
                        }
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (isContain){
                            int x = (int)event.getX();
                            int y = (int)event.getY();
                            Log.e("move",x+"--"+y);
                            child.layout(x-50,y-50,x+50,y+50);
                            rect = new Rect(x - 50, y - 50, x + 50, y + 50);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        break;
                }
                return false;
            }
        });
    }
}
