package com.zjy.daydayup.DesignPatterns.Proxy;

/**
 * Created by Hugh on 2018/6/22.
 *
 */

public interface OutWall {
    void google();
}
