package com.zjy.daydayup.DesignPatterns.Bridge;

/**
 * Created by Hugh on 2018/6/20.
 * 原型模式
 */

public interface DrawApi {
    void drawCircle(int radius,int x,int y);
}
