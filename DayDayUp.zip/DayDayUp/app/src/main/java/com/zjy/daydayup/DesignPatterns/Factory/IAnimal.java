package com.zjy.daydayup.DesignPatterns.Factory;

/**
 * Created by Hugh on 2018/6/20.
 *
 */

public interface IAnimal {
    void eat();

    void drink();
}
