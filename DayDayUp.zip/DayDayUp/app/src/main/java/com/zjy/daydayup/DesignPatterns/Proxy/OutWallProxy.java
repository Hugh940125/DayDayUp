package com.zjy.daydayup.DesignPatterns.Proxy;

/**
 * Created by Hugh on 2018/6/22.
 *
 */

public class OutWallProxy implements OutWall {

    public OutWallProxy() {
    }

    @Override
    public void google() {

    }
}
