package com.zjy.daydayup.Event;

import android.content.Context;
import android.gesture.GestureOverlayView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.LinearLayout;

/**
 * Created by Hugh on 2018/6/26.
 *
 */

public class CustomLinearLayout extends LinearLayout{
    public CustomLinearLayout(Context context) {
        super(context);
    }

    public CustomLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.e("中间层","onTouchEvent -- ");
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                performClick();
                break;
            case MotionEvent.ACTION_UP:
                break;
        }
        return super.onTouchEvent(event);//super.onTouchEvent(event)
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        Log.e("中间层","onInterceptTouchEvent -- ");
        return super.onInterceptTouchEvent(ev);//super.onInterceptTouchEvent(ev)
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.e("中间层","dispatchTouchEvent -- ");
        return super.dispatchTouchEvent(ev);//super.dispatchTouchEvent(ev)
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}
