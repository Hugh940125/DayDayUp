package com.zjy.daydayup.Event;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.RelativeLayout;

/**
 * Created by Hugh on 2018/6/27.
 *
 */

public class CustomRelativeLayout extends RelativeLayout {
    public CustomRelativeLayout(Context context) {
        super(context);
    }

    public CustomRelativeLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.e("最外层","onTouchEvent -- ");
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                performClick();
                break;
            case MotionEvent.ACTION_UP:
                break;
        }
        return super.onTouchEvent(event);//super.onTouchEvent(event)
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.e("最外层","dispatchTouchEvent -- ");
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        Log.e("最外层","onInterceptTouchEvent -- ");
        return super.onInterceptTouchEvent(ev);//super.onInterceptTouchEvent(ev)
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}
